

const initialState = {
    user: [
       { name: 'Petro',
         passport: 'NK123536',
         age: 35
       }
    ]
}


export default initialState;